import { Client } from 'whatsappy';
import { group, access } from "./system/control.js";
import UltraDB from "./system/UltraDB.js";

/* =========== Client ========== */
const client = new Client({
  phoneNumber: '201553492658', // Bot number
  prefix: [".", "/", "!"],
  fromMe: false,
  owners: [
  // Owner 1
    { name: "MIKS", lid: "12189620543589@lid", jid: "201128593180@s.whatsapp.net" },
  ],
  commandsPath: './plugins'
});

client.onGroupEvent(group);
client.onCommandAccess(access);

/* =========== Database ========== */
if (!global.db) {
    global.db = new UltraDB();
}

/* =========== Config ========== */
const { config } = client;
config.info = { 
  nameBot: "♡ 𝑻𝑬𝑺𝑻𝑩𝑶𝑻 ¥", 
  nameChannel: "𝑻𝑬𝑺𝑻¦👑¦𝑩𝑶𝑻", 
  idChannel: "120363225356834044@newsletter",
  urls: {
    repo: "https://github.com/ms9163237-lab/MIKS-BOT.git",
    api: "https://emam-api.web.id",
    channel: "https://whatsapp.com/channel/0029VbCV9ZsGU3BHSbOiOW2Z"
  },
  copyright: { 
    pack: '__MIKS__', 
    author: 'MIKS'
  },
  images: [
    "https://i.pinimg.com/originals/11/26/97/11269786cdb625c60213212aa66273a9.png",
    "https://i.pinimg.com/originals/e2/21/20/e221203f319df949ee65585a657501a2.jpg",
    "https://i.pinimg.com/originals/bb/77/0f/bb770fad66a634a6b3bf93e9c00bf4e5.jpg"
  ]
};

/* =========== Start ========== */
client.start();
